

<?php $__env->startSection('title'); ?>
    Post View
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content_title'); ?>
<h2>View Post</h2>
<ul class="nav navbar-right panel_toolbox">
    
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<table id="datatable-buttons" class="table table-striped table-bordered dataTable no-footer dtr-inline" style="width: 100%;" role="grid" aria-describedby="datatable-buttons_info">
    <thead>
        <tr>
            <th>Property/Name/Title</th>
            <th colspan="7"><?php echo e($posts->title); ?></th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Address</td>
            <td colspan="7"><?php echo e($posts->address); ?></td>
        </tr>
        <tr>
            <td>Posted By</td>
            <td colspan="7"><?php echo e($posts->user_name.' - '.$posts->user_email.' - '.$posts->user_id); ?></td>
        </tr>
        <tr>
            <td>Size:</td>
            <td><?php echo e($posts->area); ?></td>
            <td>Bad Room:</td>
            <td><?php echo e($posts->nm_bedroom); ?></td>
            <td>Bath Room:</td>
            <td><?php echo e($posts->nm_bathroom); ?></td>
            <td>Garage:</td>
            <td><?php echo e($posts->nm_garage); ?></td>
        </tr>
        <tr>
            <td>Country:</td>
            <td><?php echo e($posts->country_name); ?></td>
            <td>Division/State:</td>
            <td><?php echo e($posts->division_name); ?></td>
            <td>District:</td>
            <td><?php echo e($posts->district_name); ?></td>
            <td>Upazila/Thana:</td>
            <td><?php echo e($posts->upazila_name); ?></td>
        </tr>
        <tr>
            <td>Union/City:</td>
            <td><?php echo e($posts->union_name); ?></td>
            <td>Post Type:</td>
            <td><?php echo e($posts->post_type_name); ?></td>
            <td>Property Type:</td>
            <td><?php echo e($posts->property_type_name); ?></td>
            <td>Add. For:</td>
            <td><?php echo e($posts->property_for_name); ?></td>
        </tr>
        <tr>
            <td>Post Status:</td>
            <td><?php echo e($posts->status_name); ?></td>
            <td>Approved By:</td>
            <td><?php echo e($posts->approved_by_name); ?></td>
            <td>Post Time:</td>
            <td><?php echo e($posts->created_at); ?></td>
            <td>Update Time:</td>
            <td><?php echo e($posts->updated_at); ?></td>
        </tr>
        <tr>
            <td>Price: </td>
            <td><?php echo e($posts->price); ?></td>
            <td>Post Status: </td>
            <td><?php echo e($posts->status_name); ?></td>
            
        </tr>
        <tr>
            <td>Details</td>
            <td colspan="7"><?php echo e($posts->details); ?></td>
        </tr>
        <tr>
            <td colspan='8'>
                <img width="100%" src="<?php echo e(url('public/storage/image').$posts->image); ?>" alt="Image">
            </td>
        </tr>
        <tr>
            <td colspan="8">
                <iframe width="100%" height="400px"
                allow="accelerometer; autoplay; 
                clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen
                src="<?php echo e($posts->video); ?>" frame-border="0">
                </iframe> 
            </td>
        </tr>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\houserent\resources\views/post/view.blade.php ENDPATH**/ ?>