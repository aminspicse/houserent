
<?php $__env->startSection('title'); ?>
    Not Found
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content_title'); ?>
    <h2>Not Found</h2>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <h1>Not Found</h1>
    <h3><a href="<?php echo e($url); ?>">Back</a></h3>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\houserent\resources\views/post/not-found.blade.php ENDPATH**/ ?>