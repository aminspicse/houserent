

<?php $__env->startSection('content_title'); ?>
<h2>Edit Profile Info</h2>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<form action="<?php echo e(url('update-profile/')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Name
            <span class="required">*</span>
        </label>
        <div class="col-md-6 col-sm-6 ">
            <input name="name" value="<?php echo e(Auth::user()->name); ?>" type="text" class="form-control ">
        </div>
    </div>
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Profile Picture
            <span class="required">*</span>
        </label>
        <div class="col-md-6 col-sm-6 ">
            <input name="profilepicture" type="file" value="<?php echo e(Auth::user()->picture); ?>" class="form-control ">
        </div>
    </div>
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">
            <span class="required"></span>
        </label>
        <div class="col-md-6 col-sm-6 ">
            <input name="submit" type="submit" value="Update" class="btn btn-info ">
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\houserent\resources\views/profile/change-profile-pic.blade.php ENDPATH**/ ?>