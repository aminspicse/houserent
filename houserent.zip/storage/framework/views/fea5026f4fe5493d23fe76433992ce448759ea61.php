

<?php $__env->startSection('title'); ?>
<?php echo e($post->title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('slider'); ?>
<div class="hero-wrap" style="background-image: url('<?php echo e(asset('public/users/images/bg_1.jpg')); ?>');">
    <div class="overlay"></div>
    <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
            <div class="col-md-9 ftco-animate text-center">
                <p class="breadcrumbs"><span class="mr-2"><a href="index.html">Home</a></span> <span>Blog</span></p>
                <h1 class="mb-3 bread">Property Single</h1>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    .ftco-search {
        display: none;
    }
</style>
<section class="ftco-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="row">
                    <div class="col-md-12 ftco-animate">
                        <div class="single-slider owl-carousel">
                            <div class="item">
                                <div class="properties-img"
                                    style="background-image: url(<?php echo e(url('public/storage/image').$post->image); ?>);">
                                </div>
                            </div>
                            <!--
                            <div class="item">
                                <div class="properties-img"
                                    style="background-image: url(<?php echo e(asset('public/users/images/properties-2.jpg')); ?>);">
                                </div>
                            </div>
                            <div class="item">
                                <div class="properties-img"
                                    style="background-image: url(<?php echo e(asset('public/users/images/properties-3.jpg')); ?>);">
                                </div>
                            </div>
                            -->
                        </div>
                    </div>
                    <div class="col-md-12 Properties-single mt-4 mb-5 ftco-animate">
                        <h2><?php echo e($post->title); ?></h2>
                        <p class="rate mb-4">
                            <span class="loc"><a href="#"><i class="icon-map"></i><?php echo e($post->address); ?></a></span>
                            <span class="loc"><a href="#"><i class=""></i>Post By: <?php echo e($post->user_name); ?></a></span>
                        </p>
                        <p><?php echo e($post->details); ?></p>
                        <div class="d-md-flex mt-5 mb-5">
                            <ul>
                                <li><span>Lot Area: </span><?php echo e($post->area); ?></li>
                                <li><span>Bed Rooms: </span><?php echo e($post->nm_bedroom); ?></li>
                                <li><span>Bath Rooms: </span> <?php echo e($post->nm_bathroom); ?></li>
                                <li><span>Garage: </span><?php echo e($post->nm_garage); ?></li>
                                <li><span>Price: </span><?php echo e($post->price); ?></li>
                            </ul>
                            <ul class="ml-md-5">
                                
                                <li><span>Property For: </span> <?php echo e($post->property_for_name); ?></li>
                                <li><span>Property Type: </span> <?php echo e($post->property_type_name); ?></li>
                                <li><span>Stories: </span> 1</li>
                                <li><span>Roofing: </span> New</li>
                                
                            </ul>
                        </div>
                        <p></p>
                    </div>
                    <div class="col-md-12 properties-single ftco-animate mb-5 mt-4">
                        <h3 class="mb-4">Take A Tour</h3>
                        <!--
                        <div class="block-16">
                            <figure>
                                <img src="<?php echo e(asset('public/users/images/properties-6.jpg')); ?>" alt="Image placeholder"
                                    class="img-fluid">
                                <a href="https://www.youtube.com/watch?v=33b6VZuvHF0" class="play-button popup-vimeo"><span
                                        class="icon-play"></span></a>
                            </figure>
                        </div>
                        -->
                        <iframe width="100%"
                        height="500px"
                        src="<?php echo e($post->video); ?>">
                        </iframe> 
                    </div>

                    <div class="col-md-12 properties-single ftco-animate mb-5 mt-4">
                        <h4 class="mb-4">Review &amp; Ratings</h4>
                        <div class="row">
                            <div class="col-md-6">
                                <form method="post" class="star-rating">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                        <label class="form-check-label" for="exampleCheck1">
                                            <p class="rate"><span><i class="icon-star"></i><i class="icon-star"></i><i
                                                        class="icon-star"></i><i class="icon-star"></i><i
                                                        class="icon-star"></i> 100 Ratings</span></p>
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                        <label class="form-check-label" for="exampleCheck1">
                                            <p class="rate"><span><i class="icon-star"></i><i class="icon-star"></i><i
                                                        class="icon-star"></i><i class="icon-star"></i><i
                                                        class="icon-star-o"></i> 30 Ratings</span></p>
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                        <label class="form-check-label" for="exampleCheck1">
                                            <p class="rate"><span><i class="icon-star"></i><i class="icon-star"></i><i
                                                        class="icon-star"></i><i class="icon-star-o"></i><i
                                                        class="icon-star-o"></i> 5 Ratings</span></p>
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                        <label class="form-check-label" for="exampleCheck1">
                                            <p class="rate"><span><i class="icon-star"></i><i class="icon-star"></i><i
                                                        class="icon-star-o"></i><i class="icon-star-o"></i><i
                                                        class="icon-star-o"></i> 0 Ratings</span></p>
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                        <label class="form-check-label" for="exampleCheck1">
                                            <p class="rate"><span><i class="icon-star"></i><i class="icon-star-o"></i><i
                                                        class="icon-star-o"></i><i class="icon-star-o"></i><i
                                                        class="icon-star-o"></i> 0 Ratings</span></p>
                                        </label>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 properties-single ftco-animate mb-5 mt-5">
                        <h4 class="mb-4">Related Properties</h4>
                        <div class="row">
                            <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 ftco-animate">
                                <div class="properties">
                                    <a href="property-single.html"
                                        class="img img-2 d-flex justify-content-center align-items-center"
                                        style="background-image: url(<?php echo e(asset('public/storage/image/'.$reco->image)); ?>);">
                                        <div class="icon d-flex justify-content-center align-items-center">
                                            <span class="icon-search2"></span>
                                        </div>
                                    </a>
                                    <div class="text p-3">
                                        <span class="status sale"><?php echo e($reco->property_for_name); ?></span>
                                        <div class="d-flex">
                                            <div class="one">
                                                <h3><a href="<?php echo e(url('property-single').'/'.$reco->post_id); ?>"><?php echo e($reco->title); ?></a></h3>
                                                <p><?php echo e($reco->property_type_name); ?></p>
                                            </div>
                                            <div class="two">
                                                <span class="price"><?php echo e($reco->currency_symbol.$reco->price); ?></span>
                                            </div>
                                        </div>
                                        <p><?php echo e(substr($reco->details,0,65)); ?></p>
                                        <hr>
                                        <p class="bottom-area d-flex">
                                            <span><i class="flaticon-selection"></i> <?php echo e($reco->area); ?></span>
                                            <span class="ml-auto"><i class="flaticon-bathtub"></i> <?php echo e($reco->nm_bathroom); ?></span>
                                            <span><i class="flaticon-bed"></i> <?php echo e($reco->nm_bedroom); ?></span>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                </div>
            </div> <!-- .col-md-8 -->
            <div class="col-lg-4 sidebar ftco-animate">
                <div class="sidebar-box">
                    <form action="<?php echo e(url('search')); ?>" class="search-form">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <span class="icon fa fa-search"></span>
                            <input type="text" name="keyword" class="form-control" placeholder="Type a keyword and hit enter">
                        </div>
                    </form>
                </div>
                <div class="sidebar-box ftco-animate">
                    <div class="categories">
                        <h3>Categories</h3>
                        <?php $__currentLoopData = $property_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="#"><?php echo e($category->property_type_name); ?> <span>(<?php echo e($category->total_active); ?>)</span></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                </div>

                <div class="sidebar-box ftco-animate">
                    <h3>Recent Blog</h3>
                    <?php $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="block-21 mb-4 d-flex">
                        <a class="blog-img mr-4"
                            style="background-image: url(<?php echo e(asset('public/storage/image').'/'.$rc->image); ?>);"></a>
                        <div class="text">
                            <h3 class="heading"><a href="<?php echo e(url('property-single').'/'.$rc->post_id); ?>"><?php echo e($rc->title); ?></a></h3>
                            <div class="meta">
                                <div><a href="#"><span class="icon-calendar"></span> <?php echo e($rc->created_at); ?></a></div>
                                <div><a href="#"><span class="icon-person"></span> <?php echo e($rc->user_name); ?></a></div>
                                <!-- <div><a href="#"><span class="icon-chat"></span> 19</a></div> -->
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="sidebar-box ftco-animate">
                    <h3>Tag</h3>
                    <div class="tagcloud">
                        <!--
                        <a href="#" class="tag-cloud-link">dish</a>
                        <a href="#" class="tag-cloud-link">menu</a>
                        <a href="#" class="tag-cloud-link">food</a>
                        <a href="#" class="tag-cloud-link">sweet</a>
                        <a href="#" class="tag-cloud-link">tasty</a>
                        <a href="#" class="tag-cloud-link">delicious</a>
                        <a href="#" class="tag-cloud-link">desserts</a>
                        <a href="#" class="tag-cloud-link">drinks</a>
                        -->
                        <p class="text-danger">Under Developement</p>
                    </div>
                </div>

                <div class="sidebar-box ftco-animate">
                    <h3>Paragraph</h3>
                    <p class="text-danger">Under Developement</p>
                    <!--
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus itaque, autem necessitatibus
                        voluptate quod mollitia delectus aut, sunt placeat nam vero culpa sapiente consectetur
                        similique, inventore eos fugit cupiditate numquam!</p>
                    -->
                </div>
            </div>
        </div>
    </div>
</section> <!-- .section -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('guest.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\houserent\resources\views/guest/propertysingle.blade.php ENDPATH**/ ?>