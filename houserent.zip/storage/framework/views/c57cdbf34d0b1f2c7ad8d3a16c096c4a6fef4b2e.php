

<?php $__env->startSection('title'); ?>
    MyPost
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content_title'); ?>
<h2>My Post</h2>
<ul class="nav navbar-right panel_toolbox">
    
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<table id="datatable" class="table table-striped table-bordered"  role="grid" aria-describedby="datatable-buttons_info">
    <thead>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Address</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th><?php echo e($post->post_id); ?></th>
            <th><a href="<?php echo e(url('post').'/'.$post->post_id); ?>"><?php echo e($post->title); ?></a></th>
            <th><?php echo e($post->address); ?></th>
            <th><span><?php echo e($post->status_name); ?></span></th>
            <th>
               <a href="<?php echo e(url('post').'/'.$post->post_id); ?>/edit" class="">Edit</a>
               <a href="<?php echo e(url('/post/delete').'/'.$post->post_id); ?>" class="">Delete</a>
            </th>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\houserent\resources\views/post/index.blade.php ENDPATH**/ ?>