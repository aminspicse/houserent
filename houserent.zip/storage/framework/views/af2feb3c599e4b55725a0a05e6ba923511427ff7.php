

<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<style>
    .border-left{
        border-left: dotted;
    }
</style>
<?php $__currentLoopData = $activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row" style="boder: 1px;">
    <p><?php echo e($ac->user_agent); ?> at <?php echo e(date("Y-m-d H:i:s", $ac->last_activity)); ?></p>
    <p><?php echo e(base64_decode($ac->payload)); ?></p>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\houserent\resources\views/activity/logged-device.blade.php ENDPATH**/ ?>