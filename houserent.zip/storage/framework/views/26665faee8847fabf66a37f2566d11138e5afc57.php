
<?php $__env->startSection('title'); ?>
    Property For
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content_title'); ?>
<h2>Property For</h2>
<ul class="nav navbar-right panel_toolbox">
    <a href="<?php echo e(url('/admin/property-for/create')); ?>">Add New Property For</a>
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<table id="datatable-buttons" class="table table-striped table-bordered dataTable no-footer dtr-inline" style="width: 100%;" role="grid" aria-describedby="datatable-buttons_info">
    <thead>
        <tr>
            <th>SL</th>
            <th>Property For Name</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $i=1;?>
        <?php $__currentLoopData = $propertyFor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property_for): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i++); ?></td>
            <td><?php echo e($property_for->for_name); ?></td>
            <td>
                <?php if($property_for->for_status == 1): ?>
                
                    <form action="<?php echo e(url('admin/property-for/')); ?>/<?php echo e($property_for->for_id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit"  class="btn btn-danger ">Inactive</button>
                    </form>
                <?php else: ?>
                    <form action="<?php echo e(url('admin/property-for/')); ?>/<?php echo e($property_for->for_id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit"  class="btn btn-success ">Active</button>
                    </form>
                <?php endif; ?>
            </td>
            <td>
                <div class="row">
                    <a class="btn" href="<?php echo e(url('admin/property-for/')); ?>/<?php echo e($property_for->for_id); ?>/edit"><i class="fa fa-edit"></i></a>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\houserent\resources\views/mst/property-for/index.blade.php ENDPATH**/ ?>