

<?php $__env->startSection('title'); ?>
    Edit Profile
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content_title'); ?>
    <h2>Edit Profile Info</h2>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<form action="<?php echo e(url('update-profile/')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align">Name
            <span class="required">*</span>
        </label>
        <div class="col-md-6 col-sm-6 ">
            <input name="name" value="<?php echo e(Auth::user()->name); ?>" type="text" class="form-control ">
        </div>
    </div>
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align">Mobile
            <span class="required">*</span>
        </label>
        <div class="col-md-6 col-sm-6 ">
            <input name="mobile" value="<?php echo e(Auth::user()->mobile); ?>" type="text" class="form-control ">
        </div>
    </div>
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align">Address
            <span class="required">*</span>
        </label>
        <div class="col-md-6 col-sm-6 ">
            <input name="address" value="<?php echo e(Auth::user()->address); ?>" type="text" class="form-control ">
        </div>
    </div>
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align" >Testimonial HRS
            <span class="required">*</span>
        </label>
        <div class="col-md-6 col-sm-6 ">
            <textarea class="form-control" name="testimonial" id="" cols="30" rows="1"><?php echo e(Auth::user()->testimonial); ?></textarea>
        </div>
    </div>
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align">Profile Picture
            <span class="required">*</span>
        </label>
        <div class="col-md-6 col-sm-6 ">
            <input name="profilepicture" type="file" value="<?php echo e(Auth::user()->picture); ?>" class="form-control ">
        </div>
    </div>
    <div class="item form-group">
        <label class="col-form-label col-md-3 col-sm-3 label-align">
            <span class="required"></span>
        </label>
        <div class="col-md-6 col-sm-6 ">
            <input name="submit" type="submit" value="Update" class="btn btn-info ">
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\houserent\resources\views/profile/edit-profile.blade.php ENDPATH**/ ?>