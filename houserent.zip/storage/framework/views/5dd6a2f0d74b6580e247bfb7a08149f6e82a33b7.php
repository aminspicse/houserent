

<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<style>
    .border-left{
        border-left: dotted;
    }
</style>
<div class="row">
    <div class="col-md-12 col-sm-12 col-lg-12">
        <div class="col-md-2 col-sm-2 col-lg-2 border-left">
            <h5><i class="fa fa-user"></i> Total User</h5>
            <h3 class=""><?php echo e($total_user); ?></h3>
        </div>
        <div class="col-md-2 col-sm-2 col-lg-2 border-left">
            <h5 ><i class="fa fa-user"></i> Total Admin</h5>
            <h3 class=""><?php echo e($admin_cnt); ?></h3>
        </div>
        <div class="col-md-2 col-sm-2 col-lg-2 border-left">
            <h5 ><i class="fa fa-user"></i> Total Agent</h5>
            <h3 class=""><?php echo e($agent_cnt); ?></h3>
        </div>
        <div class="col-md-2 col-sm-2 col-lg-2 border-left">
            <h5 ><i class="fa fa-user"></i> General User</h5>
            <h3 class=""><?php echo e($user_cnt); ?></h3>
        </div>
        <div class="col-md-2 col-sm-2 col-lg-2 border-left">
            <h5 ><i class="fa fa-user"></i> Active User</h5>
            <h3 class=""><?php echo e($active_user); ?></h3>
        </div>
        <div class="col-md-2 col-sm-2 col-lg-2 border-left">
            <h5 ><i class="fa fa-user"></i> Total Post</h5>
            <h3 class=""><?php echo e($active_post); ?></h3>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\houserent\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>