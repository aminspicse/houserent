

<?php $__env->startSection('title'); ?>
    Division/State
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content_title'); ?>
<h2>Division List</h2>
<ul class="nav navbar-right panel_toolbox">
    <a href="<?php echo e(url('/admin/division/create')); ?>">Add Division/State</a>
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<table id="datatable-buttons" class="table table-striped table-bordered dataTable no-footer dtr-inline" style="width: 100%;" role="grid" aria-describedby="datatable-buttons_info">
    <thead>
        <tr>
            <th>SL</th>
            <th>Country</th>
            <th>Division/State </th>
            <th>Local Name</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $i=1;?>
        <?php $__currentLoopData = $division; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i++); ?></td>
            <td><?php echo e($division->country_name); ?></td>
            <td><?php echo e($division->division_name); ?></td>
            <td><?php echo e($division->local_name); ?></td>
            <td>
                <?php if($division->division_status == 1): ?>
                    <form action="<?php echo e(url('admin/division/')); ?>/<?php echo e($division->division_id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" title="Click for Inactive" class="btn btn-danger ">Inactive</button>
                    </form>
                <?php else: ?>
                    <form action="<?php echo e(url('admin/division/')); ?>/<?php echo e($division->division_id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" title="Click for Active" class="btn btn-success ">Active</button>
                    </form>
                <?php endif; ?>
            </td>
            <td>
                <div class="row">
                    <a class="btn" href="<?php echo e(url('admin/division/')); ?>/<?php echo e($division->division_id); ?>/edit"><i class="fa fa-edit"></i></a>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\houserent\resources\views/mst/division/index.blade.php ENDPATH**/ ?>