

<?php $__env->startSection('title'); ?>
    Inactivated Post
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content_title'); ?>
<h2>Inactivated Post</h2>
<ul class="nav navbar-right panel_toolbox">
    
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<table id="datatable-buttons" class="table table-striped table-bordered dataTable no-footer dtr-inline" style="width: 100%;" role="grid" aria-describedby="datatable-buttons_info">
    <thead>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Address</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        </tr>
            <td><?php echo e($post->post_id); ?></td>
            <td><a href="<?php echo e(url('admin/view-post').'/'.$post->post_id); ?>"><?php echo e($post->title); ?></a></td>
            <td><?php echo e($post->address); ?></td>
            <td>
                <ul class="" style="list-style:none">
                    <li class="nav-item dropdown open" style="">
                        <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true"
                            id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                            Action
                        </a>
                        <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
                           <a class="dropdown-item" href="<?php echo e(url('admin/change-status').'/'.$post->post_id); ?>/1">Active</a>
                            <a class="dropdown-item" href="<?php echo e(url('admin/change-status').'/'.$post->post_id); ?>/2">Pending</a>
                        </div>
                    </li>
                </ul>
               
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\houserent\resources\views/admin/managepost/inactive-post.blade.php ENDPATH**/ ?>