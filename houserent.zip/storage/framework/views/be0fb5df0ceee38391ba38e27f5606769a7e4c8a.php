

<?php $__env->startSection('title'); ?>
    Country List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content_title'); ?>
<h2>Country List</h2>
<ul class="nav navbar-right panel_toolbox">
    <a href="<?php echo e(url('/admin/country/create')); ?>">Add New Country</a>
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<table id="datatable-buttons" class="table table-striped table-bordered dataTable no-footer dtr-inline" style="width: 100%;" role="grid" aria-describedby="datatable-buttons_info">
    <thead>
        <tr>
            <th>SL</th>
            <th>Country</th>
            <th>Country Code</th>
            <th>Dial Code</th>
            <th>Currency Name</th>
            <th>Currency Symbol</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $i=1;?>
        <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i++); ?></td>
            <td><?php echo e($country->country_name); ?></td>
            <td><?php echo e($country->country_code); ?></td>
            <td><?php echo e($country->dial_code); ?></td>
            <td><?php echo e($country->currency_name); ?></td>
            <td><?php echo e($country->currency_symbol); ?></td>
            <td>
                <?php if($country->country_status == 1): ?>
                
                    <form action="<?php echo e(url('admin/country/')); ?>/<?php echo e($country->country_id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit"  class="btn btn-danger ">Inactive</button>
                    </form>
                <?php else: ?>
                    <form action="<?php echo e(url('admin/country/')); ?>/<?php echo e($country->country_id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit"  class="btn btn-success ">Active</button>
                    </form>
                <?php endif; ?>
            </td>
            <td>
                <div class="row">
                    <a class="btn" href="<?php echo e(url('admin/country/')); ?>/<?php echo e($country->country_id); ?>/edit"><i class="fa fa-edit"></i></a>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\houserent\resources\views/mst/country/index.blade.php ENDPATH**/ ?>