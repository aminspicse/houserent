

<?php $__env->startSection('title'); ?>
Search Result
<?php $__env->stopSection(); ?>
<?php $__env->startSection('slider'); ?>
<div class="hero-wrap" style="background-image: url('<?php echo e(asset('public/users/images/bg_1.jpg')); ?>');">
    <div class="overlay"></div>
    <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
            <div class="col-md-9 ftco-animate text-center">
                <p class="breadcrumbs"><span class="mr-2"><a href="">Search</a></span> <span>Property</span></p>
                <h1 class="mb-3 bread">Search Result</h1>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!--
	https://www.youtube.com/watch?v=1lPuwnPTOJw
-->
<section class="ftco-section bg-light">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $property; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 ftco-animate">
                <div class="properties">
                    <a href="<?php echo e(url('property-single')); ?>/<?php echo e($pro->post_id); ?>"
                        class="img img-2 d-flex justify-content-center align-items-center"
                        style="background-image: url(<?php echo e(url('public/storage/image'.$pro->image)); ?>);">
                        <div class="icon d-flex justify-content-center align-items-center">
                            <span class="icon-search2"></span>
                        </div>
                    </a>
                    <div class="text p-3">
                        <span class="status sale"><?php echo e($pro->property_for_name); ?></span>
                        <div class="d-flex">
                            <div class="one">
                                <h3><a href="<?php echo e(url('property-single').'/'.$pro->post_id); ?>"><?php echo e(substr($pro->title,0,24)); ?></a></h3>
                                <p><?php echo e($pro->property_type_name); ?></p>
                            </div>
                            <div class="two">
                                <span class="price"><?php echo e($pro->price); ?></span>
                            </div>
                        </div>
                        <p><?php echo e(substr($pro->details,0,65)); ?></p>
                        <hr>
                        <p class="bottom-area d-flex">
                            <span><i class="flaticon-selection"></i> <?php echo e($pro->area); ?></span>
                            <span class="ml-auto"><i class="flaticon-bathtub"></i> <?php echo e($pro->nm_bathroom); ?></span>
                            <span><i class="flaticon-bed"></i> <?php echo e($pro->nm_bedroom); ?></span>
                        </p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!--  -->
        <div class="row mt-5">
            <div class="col text-center">
                <div class="block-27">
                    <ul>
                        
                        <?php echo $property->links(); ?>

                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('guest.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\houserent\resources\views/guest/search/search-home.blade.php ENDPATH**/ ?>