@extends('layouts.layout')
@section('title')
    Agent Dashboard
@endsection
@section('content')

    <div class="x_content">
        <h1>Agent Dashboard</h1>
    </div>
       


@endsection