@extends('layouts.layout')

@section('content')

<h1>Dashboard 01</h1>

@endsection