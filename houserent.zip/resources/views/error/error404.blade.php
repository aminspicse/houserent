@extends('layouts.layout')

@section('title')
Error 404
@endsection
@section('content_title')
<h2>Active Post</h2>

@endsection
@section('content')

    <h1>Not Found</h1>
    <h3><a href="{{$url}}">Back</a></h3>
@endsection